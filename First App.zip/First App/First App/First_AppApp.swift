//
//  First_AppApp.swift
//  First App
//
//  Created by Salman Khan on 05/04/21.
//

import SwiftUI

@main
struct First_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
